/**
 * MyPrism
 * @constructor
 */
 function MyPrism(scene, slices, stacks) {
 	CGFobject.call(this,scene);

	this.slices = slices;
	this.stacks = stacks;

 	this.initBuffers();
 };

 MyPrism.prototype = Object.create(CGFobject.prototype);
 MyPrism.prototype.constructor = MyPrism;

 MyPrism.prototype.initBuffers = function() {
 	/*
 	* TODO:
 	* Replace the following lines in order to build a prism with a **single mesh**.
 	*
 	* How can the vertices, indices and normals arrays be defined to
 	* build a prism with varying number of slices and stacks?
 	*/
    var deg_rad = Math.PI / 180;
    this.vertices = [];
    for (i = 0; i <= this.stacks; ++i)
    {
        for (j = 0; j < this.slices; ++j)
        {
            this.vertices.push(Math.cos(deg_rad * j * (360.0 / this.slices)));
            this.vertices.push(Math.sin(deg_rad * j * (360.0 / this.slices)));
            this.vertices.push(i / this.stacks);
        }
    }
    for (i = 0; i < 5; ++i)
        this.vertices.push(0);
    this.vertices.push(1);

 	this.indices = [];
    for (i = 0; i < this.stacks; ++i)
    {
        for (j = 0; j < this.slices; ++j)
        {
            var eval;
            this.indices.push(i * this.slices + j); // 5
            this.indices.push((eval = (i * this.slices + j + 1) % ((i + 1) * this.slices)) == 0 ? (i * this.slices) : eval); // 6
            this.indices.push(i * this.slices + j + this.slices); // 11

            this.indices.push((eval = (i * this.slices + j + 1) % ((i + 1) * this.slices)) == 0 ? (i * this.slices) : eval); // 6 - 0
            this.indices.push((eval = (i * this.slices + j + 1 + this.slices) % ((i + 2) * this.slices)) == 0 ? ((i + 1) * this.slices) : eval); // 12 - 6
            this.indices.push(i * this.slices + j + this.slices); // 11
        }
    }
/*
 	this.normals = [
 	0, 0, 1,
 	0, 0, 1,
 	0, 0, 1,
 	0, 0, 1
];*/

 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
 };
